# CryptoPulse - Real-time Cryptocurrency Tracker

A responsive single-page application that displays cryptocurrency prices from the CoinGecko API, with special focus on the **Vanry/USDT pair** as the featured cryptocurrency.

## 🚀 Features

- **Real-time cryptocurrency data** from CoinGecko API
- **Vanry/USDT pair prominently featured** as the first cryptocurrency
- **Professional responsive design** with Tailwind CSS
- **Interactive price charts** with Chart.js
- **Search and filter functionality** for easy navigation
- **Dark/Light mode toggle** with localStorage persistence
- **Mobile-first responsive design** for all devices
- **Real-time updates** every 60 seconds
- **Error handling** with graceful fallbacks

## 🏃‍♂️ Quick Start

### Option 1: Direct Browser (Recommended)
1. Simply open `index.html` in your web browser
2. The app will load immediately with all dependencies from CDN

### Option 2: Local Server
```bash
# If you have Python installed
python -m http.server 8000

# Or if you have Node.js
npx serve .

# Then open http://localhost:8000
```

## 📱 How to Use

### Home Page
- Browse the cryptocurrency list with real-time prices
- **Vanry/USDT** appears first with a special "FEATURED" badge
- Use the search bar to find specific cryptocurrencies
- Sort by market cap, price change, volume, or current price
- Toggle between dark and light themes

### Detailed View
- Click any cryptocurrency card to view detailed information
- Interactive price charts with 7D, 30D, and 90D time periods
- Comprehensive statistics including market cap, volume, and all-time high
- Coin description and official website links (when available)

## 🛠 Technical Stack

- **Frontend**: Vanilla JavaScript (ES6+)
- **Styling**: Tailwind CSS
- **Charts**: Chart.js
- **Icons**: Font Awesome
- **API**: CoinGecko Free API
- **Storage**: localStorage for theme preferences

## 📊 API Integration

The app uses the CoinGecko free API with the following endpoints:
- `/coins/markets` - Main cryptocurrency list
- `/coins/{id}` - Detailed coin information
- `/coins/{id}/market_chart` - Historical price data
- Special handling for Vanry/USDT pair prioritization

## 🎨 Design Features

### Professional UI
- Modern gradient header with brand identity
- Card-based layout with smooth hover animations
- Consistent color scheme and typography
- Loading states and error messages

### Responsive Design
- **Mobile**: Single column layout
- **Tablet**: 2-column grid
- **Desktop**: 4-column grid
- **Large screens**: Optimized spacing

### Dark Mode
- System preference detection
- Manual toggle with icon change
- Smooth CSS transitions
- Chart theme switching

## 🔧 File Structure

```
/
├── index.html              # Main HTML file
├── js/
│   ├── api.js             # CoinGecko API integration
│   ├── utils.js           # Utility functions
│   ├── components.js      # UI components
│   └── app.js             # Main application logic
├── AI_ASSISTANCE_DOCUMENTATION.md
└── README.md
```

## 📈 Performance Features

- **API Caching**: 5-minute cache for API responses
- **Debounced Search**: Optimized search input handling
- **Efficient Updates**: Smart DOM manipulation
- **Visibility API**: Pauses updates when tab is inactive

## 🌟 Vanry/USDT Special Features

As requested, the Vanry/USDT pair receives special treatment:
- **Always appears first** in the cryptocurrency list
- **Featured badge** with blue highlight ring
- **Explicit USDT pair labeling**
- **Fallback API call** if not in top 100 cryptocurrencies

## 🔄 Auto-refresh

- Data refreshes automatically every 60 seconds
- Pauses when browser tab is not visible
- Resumes when tab becomes active again
- Manual refresh on navigation

## 🐛 Error Handling

- Graceful API failure handling
- User-friendly error messages
- Cached data fallbacks
- Network connectivity detection

## 🚀 Deployment

The app is ready for immediate deployment to any static hosting service:
- **Vercel**: Drag and drop the folder
- **Netlify**: Connect to your repository
- **GitHub Pages**: Enable in repository settings
- **Any web server**: Upload files to public directory

## 📝 Browser Compatibility

- **Chrome**: ✅ Fully supported
- **Firefox**: ✅ Fully supported
- **Safari**: ✅ Fully supported
- **Edge**: ✅ Fully supported
- **Mobile browsers**: ✅ Responsive design

## 🔐 Privacy & Security

- No user data collection
- Client-side only application
- HTTPS-ready (works with secure hosting)
- No authentication required

## 📞 Support

For issues or questions:
1. Check the browser console for errors
2. Ensure internet connectivity for API access
3. Try refreshing the page
4. Check CoinGecko API status if data isn't loading

## 📄 License

This project is open source and available under the MIT License.
