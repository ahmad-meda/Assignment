/**
 * UI Components for the cryptocurrency app
 */

const Components = {
    /**
     * Create a cryptocurrency card component
     */
    createCryptoCard(coin) {
        const changeClass = Utils.getChangeColorClass(coin.price_change_percentage_24h);
        const trendIcon = Utils.getTrendIcon(coin.price_change_percentage_24h);
        const isVanry = coin.symbol.toLowerCase() === 'vanry' || coin.id.toLowerCase().includes('vanry');
        
        return `
            <div class="crypto-card bg-white dark:bg-gray-800 rounded-lg shadow-md card-hover cursor-pointer p-6 ${isVanry ? 'ring-2 ring-blue-500 border-blue-500' : ''}" 
                 data-coin-id="${coin.id}">
                ${isVanry ? '<div class="absolute top-2 right-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full">FEATURED</div>' : ''}
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center">
                        <img src="${Utils.getCoinImageUrl(coin)}" 
                             alt="${coin.name}" 
                             class="w-12 h-12 rounded-full mr-3"
                             onerror="this.src='https://via.placeholder.com/48x48/cccccc/ffffff?text=${coin.symbol.charAt(0).toUpperCase()}'">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">${coin.name}</h3>
                            <p class="text-gray-500 dark:text-gray-400 uppercase">${coin.symbol}</p>
                        </div>
                    </div>
                    ${coin.market_cap_rank ? `<div class="text-sm text-gray-500 dark:text-gray-400">#${coin.market_cap_rank}</div>` : ''}
                </div>
                
                <div class="space-y-2">
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-gray-900 dark:text-white">
                            ${Utils.formatCurrency(coin.current_price)}
                        </span>
                        <div class="flex items-center ${changeClass}">
                            <i class="${trendIcon} mr-1"></i>
                            <span class="font-semibold">
                                ${Utils.formatPercentage(coin.price_change_percentage_24h)}
                            </span>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Market Cap</p>
                            <p class="text-sm font-semibold text-gray-900 dark:text-white">
                                $${Utils.formatLargeNumber(coin.market_cap)}
                            </p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Volume (24h)</p>
                            <p class="text-sm font-semibold text-gray-900 dark:text-white">
                                $${Utils.formatLargeNumber(coin.total_volume)}
                            </p>
                        </div>
                    </div>
                </div>
                
                ${isVanry ? '<div class="mt-4 text-center"><span class="text-blue-500 text-sm font-medium">VANRY/USDT Pair</span></div>' : ''}
            </div>
        `;
    },

    /**
     * Create detailed view component
     */
    createDetailView(coin, historicalData) {
        const changeClass = Utils.getChangeColorClass(coin.market_data?.price_change_percentage_24h);
        const trendIcon = Utils.getTrendIcon(coin.market_data?.price_change_percentage_24h);
        const currentPrice = coin.market_data?.current_price?.usd || 0;
        const priceChange24h = coin.market_data?.price_change_percentage_24h || 0;
        
        return `
            <div class="detail-view">
                <!-- Header Section -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
                    <div class="flex flex-col md:flex-row items-start md:items-center justify-between">
                        <div class="flex items-center mb-4 md:mb-0">
                            <img src="${Utils.getCoinImageUrl(coin)}" 
                                 alt="${coin.name}" 
                                 class="w-16 h-16 rounded-full mr-4"
                                 onerror="this.src='https://via.placeholder.com/64x64/cccccc/ffffff?text=${coin.symbol.charAt(0).toUpperCase()}'">
                            <div>
                                <h1 class="text-3xl font-bold text-gray-900 dark:text-white">${coin.name}</h1>
                                <p class="text-xl text-gray-500 dark:text-gray-400 uppercase">${coin.symbol}</p>
                                ${coin.market_data?.market_cap_rank ? `<p class="text-sm text-gray-500 dark:text-gray-400">Rank #${coin.market_data.market_cap_rank}</p>` : ''}
                            </div>
                        </div>
                        
                        <div class="text-right">
                            <div class="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                                ${Utils.formatCurrency(currentPrice)}
                            </div>
                            <div class="flex items-center justify-end ${changeClass}">
                                <i class="${trendIcon} mr-2"></i>
                                <span class="text-xl font-semibold">
                                    ${Utils.formatPercentage(priceChange24h)}
                                </span>
                                <span class="text-sm text-gray-500 dark:text-gray-400 ml-2">24h</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Chart Section -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-bold text-gray-900 dark:text-white">Price Chart</h2>
                        <div class="flex space-x-2">
                            <button class="chart-period-btn px-3 py-1 text-sm rounded-lg bg-blue-500 text-white" data-days="7">7D</button>
                            <button class="chart-period-btn px-3 py-1 text-sm rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300" data-days="30">30D</button>
                            <button class="chart-period-btn px-3 py-1 text-sm rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300" data-days="90">90D</button>
                        </div>
                    </div>
                    <div class="relative">
                        <canvas id="priceChart" class="w-full h-80"></canvas>
                    </div>
                </div>

                <!-- Statistics Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <h3 class="text-sm text-gray-500 dark:text-gray-400 mb-2">Market Cap</h3>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">
                            $${Utils.formatLargeNumber(coin.market_data?.market_cap?.usd || 0)}
                        </p>
                    </div>
                    
                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <h3 class="text-sm text-gray-500 dark:text-gray-400 mb-2">24h Volume</h3>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">
                            $${Utils.formatLargeNumber(coin.market_data?.total_volume?.usd || 0)}
                        </p>
                    </div>
                    
                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <h3 class="text-sm text-gray-500 dark:text-gray-400 mb-2">Circulating Supply</h3>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">
                            ${Utils.formatLargeNumber(coin.market_data?.circulating_supply || 0)}
                        </p>
                        <p class="text-sm text-gray-500 dark:text-gray-400">${coin.symbol.toUpperCase()}</p>
                    </div>
                    
                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                        <h3 class="text-sm text-gray-500 dark:text-gray-400 mb-2">All-Time High</h3>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">
                            ${Utils.formatCurrency(coin.market_data?.ath?.usd || 0)}
                        </p>
                        ${coin.market_data?.ath_date?.usd ? `<p class="text-sm text-gray-500 dark:text-gray-400">${new Date(coin.market_data.ath_date.usd).toLocaleDateString()}</p>` : ''}
                    </div>
                </div>

                <!-- Description Section -->
                ${coin.description?.en ? `
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4">About ${coin.name}</h2>
                    <div class="text-gray-700 dark:text-gray-300 prose max-w-none">
                        ${coin.description.en.substring(0, 500)}${coin.description.en.length > 500 ? '...' : ''}
                    </div>
                    ${coin.links?.homepage?.[0] ? `
                    <div class="mt-4">
                        <a href="${coin.links.homepage[0]}" target="_blank" rel="noopener noreferrer" 
                           class="inline-flex items-center text-blue-500 hover:text-blue-600 transition-colors">
                            <i class="fas fa-external-link-alt mr-2"></i>
                            Visit Website
                        </a>
                    </div>
                    ` : ''}
                </div>
                ` : ''}
            </div>
        `;
    },

    /**
     * Create and update the price chart
     */
    createPriceChart(historicalData, coinName) {
        const ctx = document.getElementById('priceChart');
        if (!ctx) return;

        // Destroy existing chart if it exists
        if (window.priceChartInstance) {
            window.priceChartInstance.destroy();
        }

        const prices = historicalData.prices || [];
        const labels = prices.map(price => Utils.formatDate(price[0]));
        const data = prices.map(price => price[1]);

        const isDarkMode = document.documentElement.classList.contains('dark');
        const textColor = isDarkMode ? '#e5e7eb' : '#374151';
        const gridColor = isDarkMode ? '#374151' : '#e5e7eb';

        window.priceChartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: `${coinName} Price (USD)`,
                    data: data,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0,
                    pointHoverRadius: 6,
                    pointHoverBackgroundColor: '#3b82f6',
                    pointHoverBorderColor: '#ffffff',
                    pointHoverBorderWidth: 2,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
                        titleColor: textColor,
                        bodyColor: textColor,
                        borderColor: gridColor,
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                return `Price: ${Utils.formatCurrency(context.parsed.y)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        display: true,
                        grid: {
                            color: gridColor,
                            drawBorder: false,
                        },
                        ticks: {
                            color: textColor,
                            maxTicksLimit: 7
                        }
                    },
                    y: {
                        display: true,
                        grid: {
                            color: gridColor,
                            drawBorder: false,
                        },
                        ticks: {
                            color: textColor,
                            callback: function(value) {
                                return Utils.formatCurrency(value);
                            }
                        }
                    }
                }
            }
        });
    },

    /**
     * Create loading placeholder cards
     */
    createLoadingCards(count = 8) {
        let html = '';
        for (let i = 0; i < count; i++) {
            html += `
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 animate-pulse">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-gray-300 dark:bg-gray-600 rounded-full mr-3"></div>
                            <div>
                                <div class="h-4 bg-gray-300 dark:bg-gray-600 rounded w-24 mb-2"></div>
                                <div class="h-3 bg-gray-300 dark:bg-gray-600 rounded w-16"></div>
                            </div>
                        </div>
                        <div class="h-4 bg-gray-300 dark:bg-gray-600 rounded w-8"></div>
                    </div>
                    <div class="space-y-2">
                        <div class="flex justify-between items-center">
                            <div class="h-6 bg-gray-300 dark:bg-gray-600 rounded w-20"></div>
                            <div class="h-4 bg-gray-300 dark:bg-gray-600 rounded w-16"></div>
                        </div>
                        <div class="grid grid-cols-2 gap-4 pt-4">
                            <div>
                                <div class="h-3 bg-gray-300 dark:bg-gray-600 rounded w-16 mb-1"></div>
                                <div class="h-4 bg-gray-300 dark:bg-gray-600 rounded w-12"></div>
                            </div>
                            <div>
                                <div class="h-3 bg-gray-300 dark:bg-gray-600 rounded w-16 mb-1"></div>
                                <div class="h-4 bg-gray-300 dark:bg-gray-600 rounded w-12"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
        return html;
    }
};
